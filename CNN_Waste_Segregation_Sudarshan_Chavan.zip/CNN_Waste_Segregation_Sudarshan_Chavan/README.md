📊 Findings About the Data
Class Distribution:

The dataset contains 7 classes: Cardboard, Food_Waste, Glass, Metal, Other, Paper, and Plastic.
Some classes, like Plastic (459 samples), have significantly more examples than others like Cardboard (108 samples).
This class imbalance can lead to biased model performance (e.g., higher recall for Plastic).
Image Sizes:
Images were resized to 128×128 pixels for consistency, ensuring uniform input shape for the model.
Label Encoding:
Labels were one-hot encoded, making them compatible with categorical classification using softmax.

🤖 Model Training Summary

1) Architecture:
3 Convolutional Layers (with ReLU, BatchNorm, MaxPooling)
Fully connected dense layers with Dropout to prevent overfitting
Softmax layer for multiclass classification

2) Training Setup:
Optimizer: Adam
Loss Function: Categorical Crossentropy
Batch Size: 32
Epochs: 20
Input Shape: (128, 128, 3)
Total Parameters: Moderate (good balance of complexity vs. speed)

3) Performance on Validation Set:
Metric	Value
Accuracy	61.84%
Precision	62.12%
Recall		61.84%
F1 Score	61.07%

4) Class-wise Performance:
Plastic: Highest recall (0.79), likely due to class having more data.
Glass and Other: Lower recall & F1-score, likely due to fewer examples or similar features to other classes.
Cardboard, Food_Waste, and Metal perform reasonably well.


